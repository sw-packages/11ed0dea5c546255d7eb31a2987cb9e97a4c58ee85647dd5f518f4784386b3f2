#define PIXMAN_FB_ACCESSORS

#include "pixman-access.c"
